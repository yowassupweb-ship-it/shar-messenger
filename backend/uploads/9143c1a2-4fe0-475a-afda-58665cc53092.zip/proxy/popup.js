const elements = {
  tabHome: document.getElementById("tabHome"),
  tabProxy: document.getElementById("tabProxy"),
  tabSettings: document.getElementById("tabSettings"),
  tabLogs: document.getElementById("tabLogs"),

  panelHome: document.getElementById("panelHome"),
  panelProxy: document.getElementById("panelProxy"),
  panelSettings: document.getElementById("panelSettings"),
  panelLogs: document.getElementById("panelLogs"),

  mainToggleBtn: document.getElementById("mainToggleBtn"),
  mainToggleIcon: document.getElementById("mainToggleIcon"),
  ghostModeBadge: document.getElementById("ghostModeBadge"),
  pauseGhostModeBtn: document.getElementById("pauseGhostModeBtn"),
  mainToggleLabel: document.getElementById("mainToggleLabel"),
  statusDot: document.getElementById("statusDot"),
  statusText: document.getElementById("statusText"),
  homeSpeed: document.getElementById("homeSpeed"),
  homeVolume: document.getElementById("homeVolume"),
  homeProfileSelect: document.getElementById("homeProfileSelect"),

  proxyEnabled: document.getElementById("proxyEnabled"),
  host: document.getElementById("host"),
  port: document.getElementById("port"),
  proxyType: document.getElementById("proxyType"),
  enabledByDefault: document.getElementById("enabledByDefault"),
  username: document.getElementById("username"),
  password: document.getElementById("password"),
  togglePasswordBtn: document.getElementById("togglePasswordBtn"),
  bypassList: document.getElementById("bypassList"),

  profileName: document.getElementById("profileName"),
  profilesList: document.getElementById("profilesList"),
  refreshProfilesBtn: document.getElementById("refreshProfilesBtn"),
  saveAlwaysProxyBtn: document.getElementById("saveAlwaysProxyBtn"),
  saveProxySettingsBtn: document.getElementById("saveProxySettingsBtn"),
  saveProfileBtn: document.getElementById("saveProfileBtn"),
  deleteProfileBtn: document.getElementById("deleteProfileBtn"),
  importFromClipboardBtn: document.getElementById("importFromClipboardBtn"),
  testProxyBtn: document.getElementById("testProxyBtn"),

  splitProxyEnabled: document.getElementById("splitProxyEnabled"),
  splitProxySites: document.getElementById("splitProxySites"),
  noProxySites: document.getElementById("noProxySites"),
  privacyEnabled: document.getElementById("privacyEnabled"),
  fullLockdownMode: document.getElementById("fullLockdownMode"),
  blockThirdPartyCookies: document.getElementById("blockThirdPartyCookies"),
  blockRtcLeak: document.getElementById("blockRtcLeak"),
  sendDnt: document.getElementById("sendDnt"),
  cookieAutoClearMinutes: document.getElementById("cookieAutoClearMinutes"),
  clearCookiesBottomBtn: document.getElementById("clearCookiesBottomBtn"),
  clearSiteDataBtn: document.getElementById("clearSiteDataBtn"),
  resetExtensionDataBtn: document.getElementById("resetExtensionDataBtn"),
  saveSettingsBtn: document.getElementById("saveSettingsBtn"),

  logsOutput: document.getElementById("logsOutput"),
  refreshLogsBtn: document.getElementById("refreshLogsBtn"),
  clearLogsBtn: document.getElementById("clearLogsBtn"),

  flash: document.getElementById("flash")
};

let trafficTimer = null;
let pingTimer = null;
let lastPingMs = null;
let proxyProfiles = [];
let selectedProfileId = "";
let persistedAlwaysProxyMode = false;
let ghostModePaused = false;
const ALWAYS_PROXY_OFF_HINT =
  'Если вы хотите выключить прокси, выключите режим "Всегда через прокси", или добавьте нужный сайт в "Сайты без прокси"';

const ICONS = {
  power: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 2a1 1 0 0 1 1 1v8a1 1 0 1 1-2 0V3a1 1 0 0 1 1-1Zm0 20a9 9 0 0 1-6.36-15.36 1 1 0 0 1 1.41 1.41A7 7 0 1 0 16.95 8.05a1 1 0 1 1 1.41-1.41A9 9 0 0 1 12 22Z" fill="currentColor"/></svg>',
  lock: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 10V8a5 5 0 0 1 10 0v2h1.2A1.8 1.8 0 0 1 20 11.8v8.4A1.8 1.8 0 0 1 18.2 22H5.8A1.8 1.8 0 0 1 4 20.2v-8.4A1.8 1.8 0 0 1 5.8 10H7Zm2 0h6V8a3 3 0 1 0-6 0v2Zm3 3a2 2 0 0 1 1 3.73V18a1 1 0 1 1-2 0v-1.27A2 2 0 0 1 12 13Z" fill="currentColor"/></svg>',
  ghost: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 3a7 7 0 0 0-7 7v9a1 1 0 0 0 1.71.7L8 18.41l1.29 1.29a1 1 0 0 0 1.42 0L12 18.41l1.29 1.29a1 1 0 0 0 1.42 0L16 18.41l1.29 1.29A1 1 0 0 0 19 19v-9a7 7 0 0 0-7-7Zm-2.2 8.7a1.2 1.2 0 1 1 0 2.4a1.2 1.2 0 0 1 0-2.4Zm4.4 0a1.2 1.2 0 1 1 0 2.4a1.2 1.2 0 0 1 0-2.4Z" fill="currentColor"/></svg>',
  pause: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 5a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0V6a1 1 0 0 1 1-1Zm8 0a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0V6a1 1 0 0 1 1-1Z" fill="currentColor"/></svg>',
  eye: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5c5.7 0 9.46 5.37 9.62 5.6a1 1 0 0 1 0 1.14C21.46 11.97 17.7 17.34 12 17.34s-9.46-5.37-9.62-5.6a1 1 0 0 1 0-1.14C2.54 10.37 6.3 5 12 5Zm0 2c-3.9 0-6.86 3.27-7.56 4 .7.73 3.66 4 7.56 4s6.86-3.27 7.56-4c-.7-.73-3.66-4-7.56-4Zm0 1.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Z" fill="currentColor"/></svg>',
  eyeOff: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m4.71 3.29 16 16a1 1 0 0 1-1.42 1.42l-2.26-2.26A11.49 11.49 0 0 1 12 19c-5.7 0-9.46-5.37-9.62-5.6a1 1 0 0 1 0-1.14 20.7 20.7 0 0 1 3.64-3.83L3.29 4.71a1 1 0 0 1 1.42-1.42ZM7.47 9.88a15.56 15.56 0 0 0-3.03 2.95c.7.73 3.66 4 7.56 4 1.27 0 2.41-.34 3.41-.85l-1.83-1.83A3.5 3.5 0 0 1 8.85 10.4L7.47 9.88Zm4.26-4.88c5.54.13 9.2 5.36 9.35 5.6a1 1 0 0 1 0 1.14 20.2 20.2 0 0 1-2.67 3.04l-1.42-1.42a16.32 16.32 0 0 0 2.02-2.19c-.66-.69-3.3-3.62-6.99-3.96L11.73 5Z" fill="currentColor"/></svg>'
};

init();

async function init() {
  bindUi();
  activateTab("home");
  setPasswordEyeIcon(false);
  elements.ghostModeBadge.innerHTML = ICONS.ghost;

  const response = await sendMessage({ type: "GET_SETTINGS" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось загрузить настройки", true);
    return;
  }

  fillForm(response.settings);
  bindAutoGrowTextareas();
  await refreshProfiles();
  await refreshLogsView();
  await refreshTrafficStats();
  await refreshProxyPing();
}

function bindUi() {
  elements.tabHome.addEventListener("click", () => activateTab("home"));
  elements.tabProxy.addEventListener("click", () => activateTab("proxy"));
  elements.tabSettings.addEventListener("click", () => activateTab("settings"));
  elements.tabLogs.addEventListener("click", () => activateTab("logs"));

  elements.mainToggleBtn.addEventListener("click", onMainToggleClick);
  elements.saveProxySettingsBtn.addEventListener("click", onSaveProxySettings);
  elements.saveAlwaysProxyBtn.addEventListener("click", onSaveAlwaysProxyMode);
  elements.saveProfileBtn.addEventListener("click", onSaveProfile);
  elements.deleteProfileBtn.addEventListener("click", onDeleteSelectedProfile);
  elements.refreshProfilesBtn.addEventListener("click", refreshProfiles);
  elements.importFromClipboardBtn.addEventListener("click", onImportFromClipboardClick);
  elements.testProxyBtn.addEventListener("click", onTestProxyClick);
  elements.togglePasswordBtn.addEventListener("click", onTogglePasswordClick);
  elements.homeProfileSelect.addEventListener("change", onHomeProfileChange);
  elements.enabledByDefault.addEventListener("change", paintStatusFromForm);
  elements.statusText.addEventListener("click", onStatusPingClick);
  elements.fullLockdownMode.addEventListener("change", onFullLockdownModeChange);
  elements.pauseGhostModeBtn.addEventListener("click", onToggleGhostPauseClick);

  elements.saveSettingsBtn.addEventListener("click", onSaveSettingsOnly);
  elements.clearCookiesBottomBtn.addEventListener("click", onClearCookiesOnlyClick);
  elements.clearSiteDataBtn.addEventListener("click", onClearSiteDataClick);
  elements.resetExtensionDataBtn.addEventListener("click", onResetExtensionDataClick);

  elements.refreshLogsBtn.addEventListener("click", refreshLogsView);
  elements.clearLogsBtn.addEventListener("click", onClearLogsClick);
}

function activateTab(name) {
  const home = name === "home";
  const proxy = name === "proxy";
  const settings = name === "settings";
  const logs = name === "logs";

  elements.tabHome.classList.toggle("active", home);
  elements.tabProxy.classList.toggle("active", proxy);
  elements.tabSettings.classList.toggle("active", settings);
  elements.tabLogs.classList.toggle("active", logs);

  elements.panelHome.classList.toggle("active", home);
  elements.panelProxy.classList.toggle("active", proxy);
  elements.panelSettings.classList.toggle("active", settings);
  elements.panelLogs.classList.toggle("active", logs);

  if (home) {
    startTrafficPolling();
  } else {
    stopTrafficPolling();
  }

  if (logs) {
    refreshLogsView();
  }
}

function fillForm(settings) {
  elements.proxyEnabled.checked = Boolean(settings.proxyEnabled);
  elements.host.value = settings.host || "";
  elements.port.value = settings.port || 443;
  elements.proxyType.value = settings.proxyType || "socks5";
  elements.enabledByDefault.checked = Boolean(settings.enabledByDefault);
  elements.username.value = settings.username || "";
  elements.password.value = settings.password || "";
  elements.bypassList.value = settings.bypassList || "localhost,127.0.0.1";

  elements.splitProxyEnabled.checked = Boolean(settings.splitProxyEnabled);
  elements.splitProxySites.value = settings.splitProxySites || "";
  elements.noProxySites.value = settings.noProxySites || "";

  elements.privacyEnabled.checked = Boolean(settings.privacyEnabled);
  elements.fullLockdownMode.checked = Boolean(settings.fullLockdownMode);
  ghostModePaused = Boolean(settings.fullLockdownPaused);
  elements.blockThirdPartyCookies.checked = Boolean(settings.blockThirdPartyCookies);
  elements.blockRtcLeak.checked = Boolean(settings.blockRtcLeak);
  elements.sendDnt.checked = Boolean(settings.sendDnt);
  elements.cookieAutoClearMinutes.value = Number(settings.cookieAutoClearMinutes) || 0;
  persistedAlwaysProxyMode = Boolean(settings.enabledByDefault);

  if (!settings.proxyEnabled) {
    lastPingMs = null;
  }

  autoGrowTextarea(elements.splitProxySites);
  autoGrowTextarea(elements.noProxySites);
  syncFullLockdownControls();
  paintStatus(settings.proxyEnabled);
}

function onFullLockdownModeChange() {
  if (!elements.fullLockdownMode.checked) {
    ghostModePaused = false;
  }
  syncFullLockdownControls();
  syncGhostPauseButton();
  paintStatus(elements.proxyEnabled.checked);
}

function syncGhostPauseButton() {
  const hasGhostMode = Boolean(elements.fullLockdownMode.checked);
  elements.pauseGhostModeBtn.hidden = !hasGhostMode;
  elements.pauseGhostModeBtn.textContent = ghostModePaused
    ? "Возобновить режим призрака"
    : "Приостановить режим призрака";
}

function syncFullLockdownControls() {
  const isFullLockdown = Boolean(elements.fullLockdownMode?.checked);

  elements.privacyEnabled.disabled = isFullLockdown;
  elements.blockThirdPartyCookies.disabled = isFullLockdown;
  elements.blockRtcLeak.disabled = isFullLockdown;
  elements.sendDnt.disabled = isFullLockdown;

  if (!isFullLockdown) {
    return;
  }

  elements.privacyEnabled.checked = true;
  elements.blockThirdPartyCookies.checked = true;
  elements.blockRtcLeak.checked = true;
  elements.sendDnt.checked = true;
}

function bindAutoGrowTextareas() {
  const fields = [elements.splitProxySites, elements.noProxySites];
  fields.forEach((field) => {
    if (!field) {
      return;
    }
    field.addEventListener("input", () => autoGrowTextarea(field));
    autoGrowTextarea(field);
  });
}

function autoGrowTextarea(field) {
  if (!field) {
    return;
  }
  field.style.height = "auto";
  field.style.height = `${Math.max(field.scrollHeight, 96)}px`;
}

function paintStatusFromForm() {
  paintStatus(elements.proxyEnabled.checked);
}

function collectForm() {
  return collectFormWithOptions();
}

function collectFormWithOptions(options = {}) {
  const includeAlwaysProxyDraft = Boolean(options.includeAlwaysProxyDraft);
  return {
    proxyEnabled: elements.proxyEnabled.checked,
    host: elements.host.value.trim(),
    port: Number(elements.port.value || 443),
    proxyType: elements.proxyType.value,
    enabledByDefault: includeAlwaysProxyDraft ? elements.enabledByDefault.checked : persistedAlwaysProxyMode,
    username: elements.username.value,
    password: elements.password.value,
    bypassList: elements.bypassList.value,

    splitProxyEnabled: elements.splitProxyEnabled.checked,
    splitProxySites: elements.splitProxySites.value,
    noProxySites: elements.noProxySites.value,

    privacyEnabled: elements.privacyEnabled.checked,
    fullLockdownMode: elements.fullLockdownMode.checked,
    fullLockdownPaused: ghostModePaused,
    blockThirdPartyCookies: elements.blockThirdPartyCookies.checked,
    blockRtcLeak: elements.blockRtcLeak.checked,
    sendDnt: elements.sendDnt.checked,
    cookieAutoClearMinutes: Number(elements.cookieAutoClearMinutes.value || 0)
  };
}

async function onMainToggleClick() {
  const previousState = Boolean(elements.proxyEnabled.checked);
  if (previousState && elements.enabledByDefault.checked) {
    setFlash(ALWAYS_PROXY_OFF_HINT, true);
    return;
  }

  const nextState = !previousState;
  elements.proxyEnabled.checked = nextState;
  paintStatus(nextState);

  const saved = await onSaveProxySettings();
  if (!saved) {
    elements.proxyEnabled.checked = previousState;
    paintStatus(previousState);
  }
}

function onTogglePasswordClick() {
  const isText = elements.password.type === "text";
  elements.password.type = isText ? "password" : "text";
  setPasswordEyeIcon(!isText);
}

async function onSaveProxySettings() {
  const payload = collectForm();

  if (payload.enabledByDefault && !payload.proxyEnabled) {
    setFlash(ALWAYS_PROXY_OFF_HINT, true);
    return false;
  }

  if (payload.proxyEnabled && (!payload.host || !payload.port)) {
    setFlash("Укажи хост и порт прокси", true);
    return false;
  }

  const response = await sendMessage({ type: "SAVE_SETTINGS", payload });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось сохранить прокси", true);
    return false;
  }

  fillForm(response.settings);
  await refreshTrafficStats();
  setFlash("");
  return true;
}

async function onSaveAlwaysProxyMode() {
  const payload = collectFormWithOptions({ includeAlwaysProxyDraft: true });

  if (payload.enabledByDefault && !payload.proxyEnabled) {
    if (!payload.host || !payload.port) {
      setFlash("Укажи хост и порт, чтобы включить режим \"Всегда через прокси\"", true);
      return;
    }
    payload.proxyEnabled = true;
  }

  const response = await sendMessage({ type: "SAVE_SETTINGS", payload });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось сохранить режим", true);
    return;
  }

  fillForm(response.settings);
  await refreshTrafficStats();

  const modeLabel = elements.enabledByDefault.checked ? "включен" : "выключен";
  setFlash(`Режим "Всегда через прокси" ${modeLabel}`);
}

async function onSaveSettingsOnly() {
  const payload = collectForm();
  const response = await sendMessage({ type: "SAVE_SETTINGS", payload });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось сохранить настройки", true);
    return;
  }

  fillForm(response.settings);
  setFlash("Настройки сохранены");
}

async function onToggleGhostPauseClick() {
  if (!elements.fullLockdownMode.checked) {
    return;
  }

  const nextPaused = !ghostModePaused;
  const response = await sendMessage({
    type: "SAVE_SETTINGS",
    payload: {
      fullLockdownPaused: nextPaused
    }
  });

  if (!response?.ok) {
    setFlash(response?.error || "Не удалось переключить режим призрака", true);
    return;
  }

  fillForm(response.settings);
  setFlash(nextPaused ? "Режим призрака приостановлен" : "Режим призрака возобновлен");
}

async function refreshProfiles() {
  const response = await sendMessage({ type: "GET_PROXY_PROFILES" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось загрузить шаблоны", true);
    return;
  }

  proxyProfiles = Array.isArray(response.profiles) ? response.profiles : [];
  renderProfiles();
  renderHomeProfileSelect();
}

function renderHomeProfileSelect() {
  if (!elements.homeProfileSelect) {
    return;
  }

  if (!proxyProfiles.length) {
    elements.homeProfileSelect.innerHTML = '<option value="">Нет сохраненных профилей</option>';
    elements.homeProfileSelect.value = "";
    elements.homeProfileSelect.disabled = true;
    return;
  }

  const selectedFromSettings = findProfileIdBySettings(collectForm());
  const targetId = selectedProfileId || selectedFromSettings || "";

  elements.homeProfileSelect.innerHTML = [
    '<option value="">Выберите профиль</option>',
    ...proxyProfiles.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name || "Без названия")}</option>`)
  ].join("");

  elements.homeProfileSelect.disabled = false;
  elements.homeProfileSelect.value = targetId;
}

async function onHomeProfileChange() {
  const id = elements.homeProfileSelect.value || "";
  if (!id) {
    return;
  }

  const record = proxyProfiles.find((item) => item.id === id);
  if (!record) {
    return;
  }

  selectedProfileId = id;
  applyProfileToForm(record);
  elements.proxyEnabled.checked = true;
  paintStatus(true);
  const ok = await onSaveProxySettings();
  if (ok) {
    setFlash(`Профиль применен: ${record.name || "Без названия"}`);
  }
}

function renderProfiles() {
  if (!proxyProfiles.length) {
    elements.profilesList.innerHTML = '<div class="profile-row"><div class="profile-meta">Шаблоны пока не сохранены</div></div>';
    return;
  }

  elements.profilesList.innerHTML = proxyProfiles
    .map((item) => {
      const p = item.profile || {};
      const hostPort = `${p.host || "-"}:${p.port || "-"}`;
      return `
        <div class="profile-row" data-id="${escapeHtml(item.id)}">
          <div class="profile-title">${escapeHtml(item.name || "Без названия")}</div>
          <div class="profile-meta">${escapeHtml(hostPort)} • ${(p.proxyType || "socks5").toUpperCase()}</div>
          <div class="profile-actions">
            <button class="btn ghost" data-action="apply" data-id="${escapeHtml(item.id)}" type="button">Сохранить</button>
            <button class="btn ghost" data-action="test" data-id="${escapeHtml(item.id)}" type="button">Тест</button>
            <button class="btn ghost" data-action="delete" data-id="${escapeHtml(item.id)}" type="button">Удалить</button>
          </div>
        </div>
      `;
    })
    .join("");

  elements.profilesList.querySelectorAll("button[data-action]").forEach((btn) => {
    btn.addEventListener("click", onProfileActionClick);
  });
}

async function onProfileActionClick(event) {
  const btn = event.currentTarget;
  const action = btn.getAttribute("data-action");
  const id = btn.getAttribute("data-id") || "";
  selectedProfileId = id;

  const profileRecord = proxyProfiles.find((item) => item.id === id);
  if (!profileRecord) {
    return;
  }

  if (action === "apply") {
    applyProfileToForm(profileRecord);
    setFlash("Шаблон применен в форму");
    return;
  }

  if (action === "delete") {
    await deleteProfileById(id);
    return;
  }

  if (action === "test") {
    applyProfileToForm(profileRecord);
    await onTestProxyClick();
  }
}

function applyProfileToForm(record) {
  const p = record.profile || {};
  elements.profileName.value = record.name || "";
  elements.host.value = p.host || "";
  elements.port.value = p.port || 443;
  elements.proxyType.value = p.proxyType || "socks5";
  elements.enabledByDefault.checked = persistedAlwaysProxyMode;
  elements.username.value = p.username || "";
  elements.password.value = p.password || "";
  elements.bypassList.value = p.bypassList || "localhost,127.0.0.1";
  renderHomeProfileSelect();
}

async function onSaveProfile() {
  const form = collectForm();
  const name = elements.profileName.value.trim();
  if (!name) {
    setFlash("Укажи название шаблона", true);
    return;
  }

  if (!form.host || !form.port) {
    setFlash("Для шаблона нужен хост и порт", true);
    return;
  }

  const response = await sendMessage({
    type: "SAVE_PROXY_PROFILE",
    payload: {
      id: selectedProfileId,
      name,
      profile: {
        host: form.host,
        port: form.port,
        proxyType: form.proxyType,
        enabledByDefault: form.enabledByDefault,
        username: form.username,
        password: form.password,
        bypassList: form.bypassList
      }
    }
  });

  if (!response?.ok) {
    setFlash(response?.error || "Не удалось сохранить шаблон", true);
    return;
  }

  selectedProfileId = findProfileIdByName(response.profiles || [], name) || selectedProfileId;
  proxyProfiles = response.profiles || [];
  renderProfiles();
  setFlash("Шаблон сохранен");
}

async function onDeleteSelectedProfile() {
  if (!selectedProfileId) {
    setFlash("Сначала выбери шаблон из списка", true);
    return;
  }
  await deleteProfileById(selectedProfileId);
}

async function deleteProfileById(id) {
  const response = await sendMessage({ type: "DELETE_PROXY_PROFILE", payload: { id } });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось удалить шаблон", true);
    return;
  }

  proxyProfiles = response.profiles || [];
  if (selectedProfileId === id) {
    selectedProfileId = "";
  }
  renderProfiles();
  setFlash("Шаблон удален");
}

async function onImportFromClipboardClick() {
  let raw = "";
  try {
    raw = await navigator.clipboard.readText();
  } catch {
    setFlash("Не удалось прочитать буфер обмена", true);
    return;
  }

  const parsed = parseProxyFromText(raw);
  if (!parsed) {
    setFlash("Неверный формат прокси", true);
    return;
  }

  elements.host.value = parsed.host;
  elements.port.value = parsed.port;
  elements.proxyType.value = parsed.proxyType || "socks5";
  elements.username.value = parsed.username;
  elements.password.value = parsed.password;
  elements.proxyEnabled.checked = true;
  setFlash("Прокси импортирован");
}

async function onTestProxyClick() {
  const payload = collectForm();
  if (!payload.host || !payload.port) {
    setFlash("Укажи хост и порт для теста", true);
    return;
  }

  payload.proxyEnabled = true;

  const saveResponse = await sendMessage({ type: "SAVE_SETTINGS", payload });
  if (!saveResponse?.ok) {
    setFlash(saveResponse?.error || "Не удалось сохранить перед тестом", true);
    return;
  }

  const testResult = await testProxyStrict(payload);
  if (!testResult.ok) {
    setFlash(testResult.error || "Проверка не пройдена", true);
    return;
  }

  const pingText = Number.isFinite(testResult.pingMs) ? `${testResult.pingMs} мс` : "--";
  const speedText = Number.isFinite(testResult.speedKbps) ? `${testResult.speedKbps} KB/s` : "--";
  const availability = testResult.availability || { passed: 0, total: 0, failed: [] };
  const failedText = Array.isArray(availability.failed) && availability.failed.length ? `; сбои: ${availability.failed.join(", ")}` : "";
  setFlash(
    `Прокси работает. IP: ${testResult.externalIp}; Пинг: ${pingText}; Скорость: ${speedText}; Доступность: ${availability.passed}/${availability.total}${failedText}`
  );
}

async function onClearCookiesOnlyClick() {
  setFlash("Очищаю cookie...");
  const response = await sendMessage({ type: "CLEAR_COOKIES_NOW" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось очистить cookie", true);
    return;
  }

  const removed = Number(response?.removed || 0);
  if (removed > 0) {
    setFlash(`Cookie очищены: ${removed}`);
    return;
  }

  setFlash("Cookie очищены");
}

async function onClearSiteDataClick() {
  const response = await sendMessage({ type: "CLEAR_SITE_DATA_NOW" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось очистить кэш и данные сайтов", true);
    return;
  }
  setFlash("Кэш и данные сайтов очищены");
}

async function onResetExtensionDataClick() {
  const confirmed = window.confirm("Сбросить настройки, логи и шаблоны расширения?");
  if (!confirmed) {
    return;
  }

  const response = await sendMessage({ type: "RESET_EXTENSION_DATA" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось сбросить данные расширения", true);
    return;
  }

  setFlash("Данные расширения сброшены");
  const settingsResponse = await sendMessage({ type: "GET_SETTINGS" });
  if (settingsResponse?.ok) {
    fillForm(settingsResponse.settings);
  }
}

async function refreshLogsView() {
  const response = await sendMessage({ type: "GET_APP_LOGS" });
  if (!response?.ok) {
    elements.logsOutput.textContent = "Не удалось загрузить логи";
    return;
  }

  const logs = Array.isArray(response.logs) ? response.logs : [];
  if (!logs.length) {
    elements.logsOutput.textContent = "Логи пока пусты";
    return;
  }

  elements.logsOutput.textContent = logs
    .map((entry) => {
      const ts = formatTs(entry.ts);
      const details = entry.details ? ` | ${entry.details}` : "";
      return `${ts} | ${String(entry.level || "info").toUpperCase()} | ${entry.message}${details}`;
    })
    .join("\n");
}

async function onClearLogsClick() {
  const response = await sendMessage({ type: "CLEAR_APP_LOGS" });
  if (!response?.ok) {
    setFlash(response?.error || "Не удалось очистить логи", true);
    return;
  }

  setFlash("Логи очищены");
  await refreshLogsView();
}

function startTrafficPolling() {
  stopTrafficPolling();
  refreshTrafficStats();
  refreshProxyPing();
  trafficTimer = setInterval(refreshTrafficStats, 1000);
  pingTimer = setInterval(refreshProxyPing, 5000);
}

function stopTrafficPolling() {
  if (!trafficTimer) {
    if (pingTimer) {
      clearInterval(pingTimer);
      pingTimer = null;
    }
    return;
  }
  clearInterval(trafficTimer);
  trafficTimer = null;
  if (pingTimer) {
    clearInterval(pingTimer);
    pingTimer = null;
  }
}

async function refreshTrafficStats() {
  const response = await sendMessage({ type: "GET_TRAFFIC_STATS" });
  if (!response?.ok) {
    return;
  }

  const speedBps = Number(response?.stats?.speedBps || 0);
  const totalBytes = Number(response?.stats?.totalBytes || 0);

  elements.homeSpeed.textContent = formatSpeed(speedBps);
  elements.homeVolume.textContent = formatBytes(totalBytes);
}

async function refreshProxyPing() {
  if (!elements.proxyEnabled.checked) {
    lastPingMs = null;
    paintStatus(false);
    return null;
  }

  const response = await sendMessage({ type: "GET_PROXY_PING" });
  if (!response?.ok || !response?.enabled) {
    lastPingMs = null;
    paintStatus(elements.proxyEnabled.checked);
    return null;
  }

  const ping = Number(response?.pingMs);
  lastPingMs = Number.isFinite(ping) && ping > 0 ? Math.round(ping) : null;
  paintStatus(elements.proxyEnabled.checked);
  return lastPingMs;
}

async function onStatusPingClick() {
  if (!elements.proxyEnabled.checked) {
    setFlash("Сначала включите прокси", true);
    return;
  }

  setFlash("Измеряю пинг...");
  const pingMs = await refreshProxyPing();
  if (Number.isFinite(pingMs)) {
    setFlash(`Пинг: ${pingMs} мс`);
    return;
  }

  setFlash("Пинг недоступен", true);
}

function paintStatus(isEnabled) {
  const enabled = Boolean(isEnabled);
  const locked = Boolean(elements.enabledByDefault.checked);
  const ghostMode = Boolean(elements.fullLockdownMode.checked);
  const ghostModeActive = ghostMode && !ghostModePaused;
  if (enabled) {
    const pingText = Number.isFinite(lastPingMs) ? `${lastPingMs}` : "--";
    elements.statusText.textContent = `Подключено. Пинг: ${pingText} мс`;
  } else {
    elements.statusText.textContent = "Отключено";
  }
  elements.statusDot.classList.toggle("active", enabled);
  elements.mainToggleBtn.classList.toggle("on", enabled);
  elements.mainToggleBtn.classList.toggle("locked", locked);
  elements.mainToggleBtn.classList.toggle("ghost-mode", ghostModeActive);
  elements.ghostModeBadge.classList.toggle("active", ghostMode);
  elements.ghostModeBadge.innerHTML = ghostModePaused ? ICONS.pause : ICONS.ghost;
  elements.mainToggleIcon.innerHTML = locked ? ICONS.lock : ICONS.power;
  elements.mainToggleLabel.textContent = enabled ? "Выключить прокси" : "Включить прокси";
  syncGhostPauseButton();
}

function setPasswordEyeIcon(isTextVisible) {
  elements.togglePasswordBtn.innerHTML = isTextVisible ? ICONS.eyeOff : ICONS.eye;
}

function setFlash(text, isError = false) {
  elements.flash.textContent = text;
  elements.flash.classList.toggle("error", isError);
}

function sendMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response);
    });
  });
}

async function testProxyStrict(payload) {
  const original = await getCurrentProxySettings();
  let testTabId = null;

  try {
    await setProxySettings({
      mode: "pac_script",
      pacScript: {
        data: buildStrictTestPac(payload.host, payload.port, payload.bypassList, payload.proxyType)
      }
    });

    await delay(600);

    const tab = await chrome.tabs.create({ url: "about:blank", active: false });

    if (!tab.id) {
      return { ok: false, error: "Не удалось создать вкладку для проверки" };
    }

    testTabId = tab.id;
    const ipProbe = await runProxyProbeInTab(testTabId, "https://api.ipify.org?format=json", { readBody: true, timeoutMs: 15000 });
    if (!ipProbe.ok) {
      return { ok: false, error: ipProbe.error || "Не удалось выполнить IP-проверку" };
    }

    const externalIp = extractIp(ipProbe.body);
    if (!externalIp) {
      return { ok: false, error: "Не удалось определить внешний IP" };
    }

    const availabilityTargets = [
      { label: "Google 204", url: "https://www.gstatic.com/generate_204" },
      { label: "Clients 204", url: "https://clients3.google.com/generate_204" },
      { label: "Cloudflare", url: "https://www.cloudflare.com/cdn-cgi/trace" }
    ];

    const availabilityResults = [];
    const pingSamples = [];

    for (const target of availabilityTargets) {
      const probe = await runProxyProbeInTab(testTabId, target.url, { timeoutMs: 12000 });
      const responseMs = Number(probe?.timing?.responseMs || probe?.timing?.durationMs || 0);
      if (probe.ok && responseMs > 0) {
        pingSamples.push(responseMs);
      }

      availabilityResults.push({
        label: target.label,
        ok: Boolean(probe.ok),
        responseMs: responseMs > 0 ? Math.round(responseMs) : null
      });
    }

    const speedProbe = await runProxyProbeInTab(testTabId, "https://raw.githubusercontent.com/jquery/jquery/main/src/jquery.js", {
      timeoutMs: 18000
    });

    const speedBytes = Number(speedProbe?.timing?.decodedBodySize || speedProbe?.timing?.transferSize || 0);
    const speedDuration = Number(speedProbe?.timing?.durationMs || 0);
    const speedKbps = speedBytes > 0 && speedDuration > 0 ? Number(((speedBytes * 1000) / speedDuration / 1024).toFixed(1)) : null;

    const passed = availabilityResults.filter((item) => item.ok).length;
    const failed = availabilityResults.filter((item) => !item.ok).map((item) => item.label);
    const pingMs = pingSamples.length ? Math.round(pingSamples.reduce((sum, value) => sum + value, 0) / pingSamples.length) : null;

    if (passed === 0) {
      return {
        ok: false,
        error: "Прокси включился, но проверки доступности не пройдены"
      };
    }

    return {
      ok: true,
      externalIp,
      pingMs,
      speedKbps,
      availability: {
        passed,
        total: availabilityResults.length,
        failed
      }
    };
  } catch (error) {
    return { ok: false, error: String(error?.message || "Сетевая ошибка") };
  } finally {
    if (testTabId !== null) {
      await chrome.tabs.remove(testTabId).catch(() => {});
    }
    await restoreProxySettings(original);
  }
}

async function runProxyProbeInTab(tabId, url, options = {}) {
  const readBody = Boolean(options.readBody);
  const timeoutMs = Number(options.timeoutMs || 12000);

  try {
    await chrome.tabs.update(tabId, { url });
    await waitForTabComplete(tabId, timeoutMs);

    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      args: [readBody],
      func: (shouldReadBody) => {
        const nav = performance.getEntriesByType("navigation")[0];
        return {
          body: shouldReadBody ? document.body?.innerText || "" : "",
          timing: {
            durationMs: Number(nav?.duration || 0),
            responseMs: Number(nav?.responseStart || 0),
            decodedBodySize: Number(nav?.decodedBodySize || 0),
            transferSize: Number(nav?.transferSize || 0)
          }
        };
      }
    });

    return {
      ok: true,
      body: String(result?.body || ""),
      timing: {
        durationMs: Math.max(1, Math.round(Number(result?.timing?.durationMs || 0))),
        responseMs: Math.max(1, Math.round(Number(result?.timing?.responseMs || 0))),
        decodedBodySize: Math.max(0, Number(result?.timing?.decodedBodySize || 0)),
        transferSize: Math.max(0, Number(result?.timing?.transferSize || 0))
      }
    };
  } catch (error) {
    return { ok: false, error: String(error?.message || "Probe failed") };
  }
}

function buildStrictTestPac(host, port, bypassRaw, proxyType) {
  const bypassList = String(bypassRaw || "")
    .split(",")
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);

  const pacToken = pacTokenForType(proxyType);

  return `
var PROXY_HOST = ${JSON.stringify(host)};
var PROXY_PORT = ${Number(port)};
var BYPASS_RULES = ${JSON.stringify(bypassList)};

function _isBypassHost(host) {
  var h = (host || '').toLowerCase();
  if (!h) return false;
  if (isPlainHostName(h)) return true;
  for (var i = 0; i < BYPASS_RULES.length; i++) {
    var rule = BYPASS_RULES[i];
    if (!rule) continue;
    if (h === rule) return true;
    if (dnsDomainIs(h, '.' + rule)) return true;
  }
  return false;
}

function FindProxyForURL(url, host) {
  if (_isBypassHost(host)) return 'DIRECT';
  return '${pacToken} ' + PROXY_HOST + ':' + PROXY_PORT;
}
`;
}

function getCurrentProxySettings() {
  return new Promise((resolve) => {
    chrome.proxy.settings.get({ incognito: false }, (details) => {
      resolve(details || { value: { mode: "direct" } });
    });
  });
}

function setProxySettings(value) {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.set({ value, scope: "regular" }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}

async function restoreProxySettings(details) {
  const value = details?.value || { mode: "direct" };
  await setProxySettings(value);
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let finished = false;

    const done = (error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      if (error) reject(error);
      else resolve();
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        done();
      }
    };

    const onRemoved = (removedTabId) => {
      if (removedTabId === tabId) {
        done(new Error("Тестовая вкладка закрыта"));
      }
    };

    const timer = setTimeout(() => done(new Error("Таймаут проверки прокси")), timeoutMs);

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

function extractIp(text) {
  const raw = String(text || "").trim();
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw);
    if (parsed?.ip) return String(parsed.ip);
  } catch {
  }

  const match = raw.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
  return match ? match[0] : null;
}

function parseProxyFromText(text) {
  const value = String(text || "").trim();
  if (!value) return null;

  try {
    if (value.startsWith("socks5://") || value.startsWith("http://") || value.startsWith("https://")) {
      const url = new URL(value);
      const protocol = url.protocol.replace(":", "").toLowerCase();
      return {
        proxyType: isSupportedProxyType(protocol) ? protocol : "socks5",
        host: url.hostname,
        port: Number(url.port || 443),
        username: decodeURIComponent(url.username || ""),
        password: decodeURIComponent(url.password || "")
      };
    }
  } catch {
    return null;
  }

  const parts = value.split(":");
  if (parts.length < 2) return null;

  const host = parts[0]?.trim();
  const port = Number(parts[1]);
  const username = parts[2] ? parts[2].trim() : "";
  const password = parts[3] ? parts.slice(3).join(":").trim() : "";

  if (!host || !port) return null;

  return { proxyType: "socks5", host, port, username, password };
}

function pacTokenForType(proxyType) {
  const type = String(proxyType || "socks5").toLowerCase();
  if (type === "http") return "PROXY";
  if (type === "https") return "HTTPS";
  return "SOCKS5";
}

function isSupportedProxyType(proxyType) {
  const type = String(proxyType || "").toLowerCase();
  return type === "socks5" || type === "http" || type === "https";
}

function formatTs(ts) {
  const date = new Date(Number(ts) || Date.now());
  return date.toLocaleString("ru-RU", { hour12: false });
}

function formatSpeed(bytesPerSecond) {
  if (bytesPerSecond <= 0) return "0 KB/s";
  if (bytesPerSecond >= 1024 * 1024) return `${(bytesPerSecond / (1024 * 1024)).toFixed(2)} MB/s`;
  return `${(bytesPerSecond / 1024).toFixed(1)} KB/s`;
}

function formatBytes(bytes) {
  if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${Math.max(0, Math.round(bytes))} B`;
}

function escapeHtml(str) {
  return String(str || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function findProfileIdByName(profiles, name) {
  const n = String(name || "").trim().toLowerCase();
  const found = (profiles || []).find((item) => String(item?.name || "").trim().toLowerCase() === n);
  return found?.id || "";
}

function findProfileIdBySettings(settings) {
  const host = String(settings?.host || "").trim().toLowerCase();
  const port = Number(settings?.port || 0);
  const proxyType = String(settings?.proxyType || "socks5").toLowerCase();
  if (!host || !port) {
    return "";
  }

  const found = proxyProfiles.find((item) => {
    const profile = item?.profile || {};
    return (
      String(profile.host || "").trim().toLowerCase() === host &&
      Number(profile.port || 0) === port &&
      String(profile.proxyType || "socks5").toLowerCase() === proxyType
    );
  });

  return found?.id || "";
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
