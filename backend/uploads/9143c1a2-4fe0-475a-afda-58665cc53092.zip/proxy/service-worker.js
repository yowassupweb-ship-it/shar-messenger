const SETTINGS_KEY = "proxyPilotSettings";
const APP_LOGS_KEY = "proxyPilotAppLogs";
const TRAFFIC_STATS_KEY = "proxyPilotTrafficStats";
const PROXY_PROFILES_KEY = "proxyPilotProxyProfiles";
const MAX_APP_LOGS = 300;
const TRAFFIC_WINDOW_MS = 10_000;

const trafficState = {
  totalBytes: 0,
  recentEvents: [],
  requests: new Map()
};

let isProxyEnabledNow = false;

const DEFAULT_SETTINGS = {
  proxyEnabled: false,
  enabledByDefault: false,
  host: "",
  port: 443,
  proxyType: "socks5",
  username: "",
  password: "",
  bypassList: "localhost,127.0.0.1",
  noProxySites: "",
  splitProxyEnabled: false,
  splitProxySites: "",
  privacyEnabled: true,
  fullLockdownMode: false,
  fullLockdownPaused: false,
  blockThirdPartyCookies: true,
  blockRtcLeak: true,
  sendDnt: true,
  cookieAutoClearMinutes: 0
};

const COOKIE_CLEANUP_ALARM = "proxyPilotCookieCleanup";

chrome.runtime.onInstalled.addListener(async () => {
  const settings = await getSettings();
  await applyAll(settings);
  await initTrafficState();
  await appendAppLog("info", "Extension installed", "settings applied");
});

chrome.runtime.onStartup.addListener(async () => {
  const settings = await getSettings();
  await applyAll(settings);
  await initTrafficState();
  await appendAppLog("info", "Extension startup", "settings applied");
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== COOKIE_CLEANUP_ALARM) {
    return;
  }

  await clearCookies();
});

chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName !== "local" || !changes[SETTINGS_KEY]) {
    return;
  }

  await applyAll(changes[SETTINGS_KEY].newValue || DEFAULT_SETTINGS);
});

chrome.webRequest.onHeadersReceived.addListener(
  async (details) => {
    if (!isProxyEnabledNow) {
      return;
    }

    const requestId = String(details.requestId || "");
    if (!requestId) {
      return;
    }

    const contentLength = getContentLength(details.responseHeaders || []);
    const estimated = contentLength > 0 ? contentLength : estimateTrafficBytes(details);
    const rec = trafficState.requests.get(requestId) || { accounted: false, bytes: 0 };
    rec.bytes = Math.max(rec.bytes || 0, estimated);
    trafficState.requests.set(requestId, rec);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

chrome.webRequest.onCompleted.addListener(
  async (details) => {
    if (!isProxyEnabledNow) {
      return;
    }

    const requestId = String(details.requestId || "");
    if (!requestId) {
      return;
    }

    const rec = trafficState.requests.get(requestId) || { accounted: false, bytes: 0 };
    if (rec.accounted) {
      return;
    }

    const bytes = rec.bytes > 0 ? rec.bytes : estimateTrafficBytes(details);
    const now = Date.now();
    trafficState.totalBytes += bytes;
    trafficState.recentEvents.push({ ts: now, bytes });
    rec.accounted = true;
    rec.bytes = bytes;
    trafficState.requests.set(requestId, rec);
    trimRecentTraffic(now);
    trimRequestMap();
    await persistTrafficTotal();
  },
  { urls: ["<all_urls>"] }
);

chrome.webRequest.onErrorOccurred.addListener(
  (details) => {
    const requestId = String(details.requestId || "");
    if (!requestId) {
      return;
    }
    trafficState.requests.delete(requestId);
  },
  { urls: ["<all_urls>"] }
);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "APP_LOG") {
    appendAppLog(
      message?.payload?.level || "info",
      message?.payload?.message || "event",
      message?.payload?.details || ""
    )
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_APP_LOGS") {
    getAppLogs()
      .then((logs) => sendResponse({ ok: true, logs }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "CLEAR_APP_LOGS") {
    clearAppLogs()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_SETTINGS") {
    getSettings()
      .then((settings) => sendResponse({ ok: true, settings }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_PROXY_PROFILES") {
    getProxyProfiles()
      .then((profiles) => sendResponse({ ok: true, profiles }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "SAVE_PROXY_PROFILE") {
    saveProxyProfile(message?.payload)
      .then((profiles) => sendResponse({ ok: true, profiles }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "DELETE_PROXY_PROFILE") {
    deleteProxyProfile(message?.payload?.id)
      .then((profiles) => sendResponse({ ok: true, profiles }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_TRAFFIC_STATS") {
    const now = Date.now();
    trimRecentTraffic(now);
    const speedBps = getSpeedBytesPerSecond(now);
    sendResponse({
      ok: true,
      stats: {
        speedBps,
        totalBytes: trafficState.totalBytes,
        proxyEnabled: isProxyEnabledNow,
        ts: now
      }
    });
    return true;
  }

  if (message?.type === "GET_PROXY_PING") {
    measureProxyPing()
      .then((result) => sendResponse({ ok: true, ...result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "SAVE_SETTINGS") {
    saveSettings(message.payload)
      .then(async (settings) => {
        await applyAll(settings);
        await appendAppLog("info", "Settings saved", settings.proxyEnabled ? "proxy_on" : "proxy_off");
        sendResponse({ ok: true, settings });
      })
      .catch(async (error) => {
        await appendAppLog("error", "Save settings failed", error.message || "unknown_error");
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message?.type === "CLEAR_COOKIES_NOW") {
    clearCookies()
      .then((removed) => sendResponse({ ok: true, removed }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "CLEAR_SITE_DATA_NOW") {
    clearSiteData()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "RESET_EXTENSION_DATA") {
    resetExtensionData()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "TEST_PROXY") {
    testProxyConnection()
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  return false;
});

chrome.webRequest.onAuthRequired.addListener(
  async (details, callback) => {
    try {
      const settings = await getSettings();
      if (!details?.isProxy) {
        callback({});
        return;
      }

      if (!settings.proxyEnabled || !settings.username || !settings.password) {
        callback({});
        return;
      }

      callback({
        authCredentials: {
          username: settings.username,
          password: settings.password
        }
      });
    } catch {
      callback({});
    }
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);

async function applyAll(settings) {
  const effective = { ...settings };

  isProxyEnabledNow = Boolean(effective?.proxyEnabled);
  await Promise.all([applyProxy(effective), applyPrivacy(effective), scheduleCookieCleanup(effective)]);
}

async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  if (!result[SETTINGS_KEY]) {
    await chrome.storage.local.set({ [SETTINGS_KEY]: DEFAULT_SETTINGS });
    return structuredClone(DEFAULT_SETTINGS);
  }

  return {
    ...DEFAULT_SETTINGS,
    ...result[SETTINGS_KEY]
  };
}

async function saveSettings(partial) {
  const current = await getSettings();
  const normalizedProxyType = normalizeProxyType(partial.proxyType ?? current.proxyType);
  const merged = {
    ...current,
    ...partial,
    proxyType: normalizedProxyType,
    port: Number(partial.port ?? current.port) || 443,
    cookieAutoClearMinutes: Number(partial.cookieAutoClearMinutes ?? current.cookieAutoClearMinutes) || 0
  };

  if (merged.enabledByDefault && merged.host) {
    merged.proxyEnabled = true;
  }

  await chrome.storage.local.set({ [SETTINGS_KEY]: merged });
  return merged;
}

async function applyProxy(settings) {
  if (!settings.proxyEnabled || !settings.host) {
    await chrome.proxy.settings.set({ value: { mode: "direct" }, scope: "regular" });
    return;
  }

  const bypassFromInput = (settings.bypassList || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

  const bypassFromSites = normalizeSplitSites(settings.noProxySites || "");
  const bypassList = Array.from(new Set([...bypassFromInput, ...bypassFromSites]));

  const splitSites = normalizeSplitSites(settings.splitProxySites || "");
  const shouldUseSplitProxy = Boolean(settings.splitProxyEnabled) && splitSites.length > 0;

  if (shouldUseSplitProxy) {
    const pacScript = buildPacScript({
      proxyType: settings.proxyType,
      host: settings.host,
      port: Number(settings.port) || 443,
      splitSites,
      bypassList
    });

    await chrome.proxy.settings.set({
      scope: "regular",
      value: {
        mode: "pac_script",
        pacScript: {
          data: pacScript
        }
      }
    });
    return;
  }

  const pacScript = buildGlobalPacScript({
    proxyType: settings.proxyType,
    host: settings.host,
    port: Number(settings.port) || 443,
    bypassList
  });

  await chrome.proxy.settings.set({
    scope: "regular",
    value: {
      mode: "pac_script",
      pacScript: {
        data: pacScript
      }
    }
  });
}

async function measureProxyPing() {
  const settings = await getSettings();
  if (!settings?.proxyEnabled || !settings?.host) {
    return { enabled: false, pingMs: null };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);
  const started = performance.now();

  try {
    await fetch("https://clients3.google.com/generate_204", {
      method: "GET",
      cache: "no-store",
      signal: controller.signal
    });
    const elapsed = Math.max(1, Math.round(performance.now() - started));
    return { enabled: true, pingMs: elapsed };
  } catch {
    return { enabled: true, pingMs: null };
  } finally {
    clearTimeout(timeoutId);
  }
}

function normalizeSplitSites(raw) {
  return String(raw)
    .split(/\r?\n|,/)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean)
    .map((item) => item.replace(/^https?:\/\//, "").replace(/\/$/, ""));
}

function buildPacScript({ proxyType, host, port, splitSites, bypassList }) {
  const hostRules = JSON.stringify(splitSites);
  const bypassRules = JSON.stringify(bypassList || []);
  const pacToken = pacTokenForType(proxyType);

  return `
var PROXY_HOST = ${JSON.stringify(host)};
var PROXY_PORT = ${Number(port)};
var SPLIT_RULES = ${hostRules};
var BYPASS_RULES = ${bypassRules};
var PROXY_TOKEN = ${JSON.stringify(pacToken)};

function _isBypassHost(host) {
  var h = (host || '').toLowerCase();
  if (!h) return false;
  if (isPlainHostName(h)) return true;
  for (var i = 0; i < BYPASS_RULES.length; i++) {
    var rule = BYPASS_RULES[i].toLowerCase();
    if (!rule) continue;
    if (rule === h) return true;
    if (dnsDomainIs(h, '.' + rule)) return true;
  }
  return false;
}

function _isSplitTarget(host) {
  var h = (host || '').toLowerCase();
  if (!h) return false;
  for (var i = 0; i < SPLIT_RULES.length; i++) {
    var rule = SPLIT_RULES[i];
    if (!rule) continue;
    if (h === rule) return true;
    if (dnsDomainIs(h, '.' + rule)) return true;
  }
  return false;
}

function FindProxyForURL(url, host) {
  if (_isBypassHost(host)) {
    return 'DIRECT';
  }

  if (_isSplitTarget(host)) {
    return PROXY_TOKEN + ' ' + PROXY_HOST + ':' + PROXY_PORT + '; DIRECT';
  }

  return 'DIRECT';
}
`;
}

function buildGlobalPacScript({ proxyType, host, port, bypassList }) {
  const bypassRules = JSON.stringify(bypassList || []);
  const pacToken = pacTokenForType(proxyType);

  return `
var PROXY_HOST = ${JSON.stringify(host)};
var PROXY_PORT = ${Number(port)};
var BYPASS_RULES = ${bypassRules};
var PROXY_TOKEN = ${JSON.stringify(pacToken)};

function _isBypassHost(host) {
  var h = (host || '').toLowerCase();
  if (!h) return false;
  if (isPlainHostName(h)) return true;
  for (var i = 0; i < BYPASS_RULES.length; i++) {
    var rule = BYPASS_RULES[i].toLowerCase();
    if (!rule) continue;
    if (rule === h) return true;
    if (dnsDomainIs(h, '.' + rule)) return true;
  }
  return false;
}

function FindProxyForURL(url, host) {
  if (_isBypassHost(host)) {
    return 'DIRECT';
  }

  return PROXY_TOKEN + ' ' + PROXY_HOST + ':' + PROXY_PORT + '; DIRECT';
}
`;
}

function pacTokenForType(proxyType) {
  const type = normalizeProxyType(proxyType);
  if (type === "http") {
    return "PROXY";
  }
  if (type === "https") {
    return "HTTPS";
  }
  return "SOCKS5";
}

function normalizeProxyType(proxyType) {
  const type = String(proxyType || "socks5").toLowerCase();
  if (type === "http" || type === "https" || type === "socks5") {
    return type;
  }
  return "socks5";
}

async function applyPrivacy(settings) {
  const isFullLockdown = Boolean(settings.fullLockdownMode) && !Boolean(settings.fullLockdownPaused);
  const isPrivacyEnabled = Boolean(settings.privacyEnabled);

  if (!isPrivacyEnabled && !isFullLockdown) {
    await Promise.all([
      clearPrivacySetting(chrome.privacy.websites.thirdPartyCookiesAllowed),
      clearPrivacySetting(chrome.privacy.network.webRTCIPHandlingPolicy),
      clearPrivacySetting(chrome.privacy.websites.doNotTrackEnabled),
      clearFullLockdownPrivacy()
    ]);
    return;
  }

  const thirdPartyCookiesAllowed = isFullLockdown ? false : !settings.blockThirdPartyCookies;
  const webRtcPolicy = isFullLockdown
    ? "disable_non_proxied_udp"
    : settings.blockRtcLeak
      ? "disable_non_proxied_udp"
      : "default";
  const dntEnabled = isFullLockdown ? true : Boolean(settings.sendDnt);

  await Promise.all([
    setPrivacySetting(chrome.privacy.websites.thirdPartyCookiesAllowed, thirdPartyCookiesAllowed),
    setPrivacySetting(chrome.privacy.network.webRTCIPHandlingPolicy, webRtcPolicy),
    setPrivacySetting(chrome.privacy.websites.doNotTrackEnabled, dntEnabled),
    isFullLockdown ? applyFullLockdownPrivacy() : clearFullLockdownPrivacy()
  ]);
}

async function setPrivacySetting(setting, value) {
  if (!setting?.set) {
    return;
  }

  try {
    await setting.set({ value });
  } catch {
  }
}

async function clearPrivacySetting(setting) {
  if (!setting?.clear) {
    return;
  }

  try {
    await setting.clear({});
  } catch {
  }
}

async function applyFullLockdownPrivacy() {
  const tasks = [
    setPrivacySetting(chrome.privacy.websites.cookieConfig, { behavior: "block_all" }),
    setPrivacySetting(chrome.privacy.websites.hyperlinkAuditingEnabled, false),
    setPrivacySetting(chrome.privacy.websites.topicsEnabled, false),
    setPrivacySetting(chrome.privacy.websites.fledgeEnabled, false),
    setPrivacySetting(chrome.privacy.websites.adMeasurementEnabled, false)
  ];

  if (chrome.contentSettings?.cookies?.set) {
    tasks.push(
      chrome.contentSettings.cookies.set({
        primaryPattern: "<all_urls>",
        setting: "block",
        scope: "regular"
      })
    );
  }

  await Promise.all(tasks);
}

async function clearFullLockdownPrivacy() {
  const tasks = [
    clearPrivacySetting(chrome.privacy.websites.cookieConfig),
    clearPrivacySetting(chrome.privacy.websites.hyperlinkAuditingEnabled),
    clearPrivacySetting(chrome.privacy.websites.topicsEnabled),
    clearPrivacySetting(chrome.privacy.websites.fledgeEnabled),
    clearPrivacySetting(chrome.privacy.websites.adMeasurementEnabled)
  ];

  if (chrome.contentSettings?.cookies?.clear) {
    tasks.push(chrome.contentSettings.cookies.clear({ scope: "regular" }));
  }

  await Promise.all(tasks);
}

async function scheduleCookieCleanup(settings) {
  await chrome.alarms.clear(COOKIE_CLEANUP_ALARM);

  const periodInMinutes = Number(settings.cookieAutoClearMinutes) || 0;
  const privacyActive = Boolean(settings.privacyEnabled) || (Boolean(settings.fullLockdownMode) && !Boolean(settings.fullLockdownPaused));
  if (!privacyActive || periodInMinutes <= 0) {
    return;
  }

  await chrome.alarms.create(COOKIE_CLEANUP_ALARM, {
    delayInMinutes: periodInMinutes,
    periodInMinutes
  });
}

async function clearCookies() {
  await chrome.browsingData.remove({ since: 0 }, { cookies: true });

  const allCookies = await chrome.cookies.getAll({});
  if (!Array.isArray(allCookies) || !allCookies.length) {
    return 0;
  }

  let removedCount = 0;

  for (const cookie of allCookies) {
    const domain = String(cookie.domain || "").replace(/^\./, "");
    if (!domain) {
      continue;
    }

    const path = cookie.path || "/";
    const candidates = cookie.secure
      ? [`https://${domain}${path}`, `http://${domain}${path}`]
      : [`http://${domain}${path}`, `https://${domain}${path}`];

    let removed = false;
    for (const url of candidates) {
      try {
        const details = {
          url,
          name: cookie.name,
          storeId: cookie.storeId
        };

        if (cookie.partitionKey?.topLevelSite) {
          details.partitionKey = cookie.partitionKey;
        }

        const result = await chrome.cookies.remove(details);
        if (result) {
          removedCount += 1;
          removed = true;
          break;
        }
      } catch {
      }
    }

    if (!removed) {
      continue;
    }
  }

  return removedCount;
}

async function clearSiteData() {
  await chrome.browsingData.remove(
    { since: 0 },
    {
      appcache: true,
      cache: true,
      cacheStorage: true,
      fileSystems: true,
      indexedDB: true,
      localStorage: true,
      serviceWorkers: true,
      webSQL: true
    }
  );
}

async function resetExtensionData() {
  await chrome.alarms.clear(COOKIE_CLEANUP_ALARM);
  await chrome.storage.local.clear();

  trafficState.totalBytes = 0;
  trafficState.recentEvents = [];
  trafficState.requests.clear();

  await chrome.storage.local.set({
    [SETTINGS_KEY]: { ...DEFAULT_SETTINGS },
    [APP_LOGS_KEY]: [],
    [PROXY_PROFILES_KEY]: [],
    [TRAFFIC_STATS_KEY]: { totalBytes: 0 }
  });

  isProxyEnabledNow = false;
  await applyAll(DEFAULT_SETTINGS);
}

async function testProxyConnection() {
  const settings = await getSettings();
  if (!settings.proxyEnabled) {
    throw new Error("Прокси выключен");
  }

  const testUrl = "https://api.ipify.org?format=json";
  const tab = await chrome.tabs.create({
    url: testUrl,
    active: false
  });

  if (!tab.id) {
    throw new Error("Не удалось создать вкладку для проверки");
  }

  const tabId = tab.id;

  try {
    await waitForTabComplete(tabId, 12000);

    const [{ result: bodyText }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => document.body?.innerText || ""
    });

    const parsed = parseIpFromBody(bodyText);
    if (!parsed) {
      throw new Error("Ответ сервиса IP не распознан");
    }

    return {
      externalIp: parsed
    };
  } finally {
    await chrome.tabs.remove(tabId).catch(() => {});
  }
}

async function getAppLogs() {
  const result = await chrome.storage.local.get(APP_LOGS_KEY);
  return Array.isArray(result[APP_LOGS_KEY]) ? result[APP_LOGS_KEY] : [];
}

async function getProxyProfiles() {
  const result = await chrome.storage.local.get(PROXY_PROFILES_KEY);
  return Array.isArray(result[PROXY_PROFILES_KEY]) ? result[PROXY_PROFILES_KEY] : [];
}

async function saveProxyProfile(payload) {
  const name = String(payload?.name || "").trim();
  if (!name) {
    throw new Error("Укажи название шаблона");
  }

  const profile = payload?.profile || {};
  if (!profile.host || !profile.port) {
    throw new Error("Для шаблона нужен хост и порт");
  }

  const id = String(payload?.id || "") || slugifyName(name);
  const profiles = await getProxyProfiles();
  const record = {
    id,
    name,
    updatedAt: Date.now(),
    profile: {
      proxyEnabled: true,
      host: String(profile.host || "").trim(),
      port: Number(profile.port) || 443,
      proxyType: normalizeProxyType(profile.proxyType),
      enabledByDefault: Boolean(profile.enabledByDefault),
      username: String(profile.username || ""),
      password: String(profile.password || ""),
      bypassList: String(profile.bypassList || "localhost,127.0.0.1")
    }
  };

  const next = profiles.filter((item) => item.id !== id);
  next.unshift(record);
  await chrome.storage.local.set({ [PROXY_PROFILES_KEY]: next.slice(0, 100) });
  return next.slice(0, 100);
}

async function deleteProxyProfile(idRaw) {
  const id = String(idRaw || "").trim();
  if (!id) {
    throw new Error("Не выбран шаблон для удаления");
  }

  const profiles = await getProxyProfiles();
  const next = profiles.filter((item) => item.id !== id);
  await chrome.storage.local.set({ [PROXY_PROFILES_KEY]: next });
  return next;
}

function slugifyName(name) {
  return String(name)
    .toLowerCase()
    .trim()
    .replace(/[^a-zа-я0-9]+/giu, "-")
    .replace(/^-+|-+$/g, "") || `profile-${Date.now()}`;
}

async function clearAppLogs() {
  await chrome.storage.local.set({ [APP_LOGS_KEY]: [] });
}

async function appendAppLog(level, message, details = "") {
  const logs = await getAppLogs();
  logs.push({
    ts: Date.now(),
    level: String(level || "info").toLowerCase(),
    message: String(message || "event"),
    details: String(details || "")
  });

  const trimmed = logs.slice(-MAX_APP_LOGS);
  await chrome.storage.local.set({ [APP_LOGS_KEY]: trimmed });
}

async function initTrafficState() {
  const result = await chrome.storage.local.get(TRAFFIC_STATS_KEY);
  const saved = result?.[TRAFFIC_STATS_KEY];
  trafficState.totalBytes = Number(saved?.totalBytes || 0);
  trafficState.recentEvents = [];
  trafficState.requests = new Map();
}

async function persistTrafficTotal() {
  await chrome.storage.local.set({
    [TRAFFIC_STATS_KEY]: {
      totalBytes: trafficState.totalBytes,
      updatedAt: Date.now()
    }
  });
}

function trimRecentTraffic(nowTs) {
  const threshold = nowTs - TRAFFIC_WINDOW_MS;
  trafficState.recentEvents = trafficState.recentEvents.filter((item) => item.ts >= threshold);
}

function trimRequestMap() {
  if (trafficState.requests.size < 2000) {
    return;
  }

  let dropped = 0;
  for (const [requestId, rec] of trafficState.requests.entries()) {
    if (rec?.accounted) {
      trafficState.requests.delete(requestId);
      dropped += 1;
    }
    if (dropped >= 1000) {
      break;
    }
  }
}

function getSpeedBytesPerSecond(nowTs) {
  trimRecentTraffic(nowTs);
  if (!trafficState.recentEvents.length) {
    return 0;
  }

  const bytes = trafficState.recentEvents.reduce((sum, item) => sum + Number(item.bytes || 0), 0);
  return Math.round((bytes / TRAFFIC_WINDOW_MS) * 1000);
}

function getContentLength(headers) {
  for (const header of headers) {
    if (String(header?.name || "").toLowerCase() !== "content-length") {
      continue;
    }

    const parsed = Number(header?.value || 0);
    if (Number.isFinite(parsed) && parsed > 0) {
      return parsed;
    }
  }

  return 0;
}

function estimateTrafficBytes(details) {
  const url = String(details?.url || "").toLowerCase();
  const method = String(details?.method || "GET").toUpperCase();

  let base = 6 * 1024;

  if (url.includes(".jpg") || url.includes(".jpeg") || url.includes(".png") || url.includes(".webp") || url.includes(".avif") || url.includes(".gif") || url.includes(".svg")) {
    base = 120 * 1024;
  } else if (url.includes(".js") || url.includes(".css")) {
    base = 40 * 1024;
  } else if (url.includes(".mp4") || url.includes(".m3u8") || url.includes("video")) {
    base = 350 * 1024;
  } else if (url.includes("api") || url.includes("json")) {
    base = 18 * 1024;
  }

  if (method === "POST" || method === "PUT" || method === "PATCH") {
    base = Math.round(base * 1.2);
  }

  return base;
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    let finished = false;

    const done = (error) => {
      if (finished) {
        return;
      }
      finished = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
      if (error) {
        reject(error);
      } else {
        resolve();
      }
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) {
        return;
      }
      if (changeInfo.status === "complete") {
        done();
      }
    };

    const onRemoved = (removedTabId) => {
      if (removedTabId === tabId) {
        done(new Error("Тестовая вкладка закрыта"));
      }
    };

    const timer = setTimeout(() => {
      done(new Error("Таймаут проверки прокси"));
    }, timeoutMs);

    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
}

function parseIpFromBody(text) {
  const raw = String(text || "").trim();
  if (!raw) {
    return null;
  }

  try {
    const json = JSON.parse(raw);
    if (json?.ip) {
      return String(json.ip);
    }
  } catch {
  }

  const match = raw.match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/);
  return match ? match[0] : null;
}
